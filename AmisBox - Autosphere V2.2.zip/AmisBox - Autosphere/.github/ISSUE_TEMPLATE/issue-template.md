---
name: issue template
about: default guidelines

---

# Issue Template

## Title

"Copy of a Lint report first phrase"

## Comment

> Reproduction of the warning report.

    ´piece of affected code´
    
Brief description explaining the situation.

> IDE recommendation

    ´targeted code´

* [reference]()
* [reference]()
