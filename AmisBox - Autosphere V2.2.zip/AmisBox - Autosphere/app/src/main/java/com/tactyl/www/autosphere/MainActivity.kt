package com.tactyl.www.autosphere

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.View
import android.webkit.*
import kotlinx.android.synthetic.main.activity_webview.*
import org.jetbrains.anko.progressDialog
import org.threeten.bp.Instant

@SuppressLint("SetJavaScriptEnabled")
class MainActivity : BaseActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)

//        registerReceiver(ConnectivityReceiver(),
//                IntentFilter(ConnectivityManager.EXTRA_NO_CONNECTIVITY   .CONNECTIVITY_ACTION))

        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE                                        //Config pein ecran + desactive barres
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        supportActionBar?.hide()
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        setContentView(R.layout.activity_webview)

        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        webView.webViewClient=mywebViewClient()

        webView.visibility= View.GONE
        //imageView.visibility= View.VISIBLE
        textViewInfo.visibility= View.VISIBLE

        myButton.setOnClickListener {
            textViewInfo.text = textViewInfo.text.toString() + Instant.now() +" : Reload URL\n"
            Log.d("AMISWEB : ", "Reload URL")
            //goHome(webView)
            webView.loadUrl(getString(R.string.website_url_error))
        }


    }


    private inner class mywebViewClient : WebViewClient() {

        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
            super.onReceivedHttpError(view, request, errorResponse)

            textViewInfo.text = textViewInfo.text.toString() + Instant.now() +" : HTTP Error :\n Request : " + request.toString() + "\n errorResponse : " + errorResponse + "\n"

            Log.d("AMISWEB", " : HTTP Error :\n Request : " + request.toString() + "\n errorResponse : " + errorResponse + "\n")

            onErrorWebView("mywebViewClient-onReceivedHttpError")

        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            super.onReceivedError(view, request, error)
            textViewInfo.text = textViewInfo.text.toString() + Instant.now() +" : HTTP Error :\n Request : " + request.toString() + "\n errorResponse : " + error + "\n"
            Log.d("AMISWEB", " : HTTP Error :\n Request : " + request.toString() + "\n errorResponse : " + error + "\n")

            onErrorWebView("mywebViewClient-onReceivedError")
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            Log.d("AMISWEB : ", "onPageFinished : "+ url + " - " + webView.title)

            if (webView.title == "Page Web non disponible" || webView.title ==""){
                onErrorWebView("mywebViewClient-onPageFinished-title"+webView.title)
            }
            super.onPageFinished(view, url)
        }

        fun onErrorWebView(msg:String){
            val dialog = progressDialog(message = "La page web sera recharchée dans quelques instants …", title = "AmisBox - Erreur Page Web : " + msg)
            dialog.create()
            var countDownTimer = object : CountDownTimer(10000, 100) {
                override fun onFinish() {
                    dialog.dismiss()
                    goHome()
                }

                override fun onTick(p0: Long) {
                    //Log.d("AmisBox : ","Timer : "+p0)
                    dialog.incrementProgressBy(1)
                    if (dialog.progress>90){
                        dialog.setMessage("Chargement de la page ...")
                    }
                }
                // override object functions here, do it quicker by setting cursor on object, then type alt + enter ; implement members
            }

            countDownTimer.start()
        }

    }







}
